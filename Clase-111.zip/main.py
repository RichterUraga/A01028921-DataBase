import csv

with open ("TextFiles/populationbycountry19802010millions.csv") as csvFile:
  reader = csv.reader(csvFile)
  first_row = list(reader)[0]
  print (first_row)